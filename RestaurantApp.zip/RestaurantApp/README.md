<h1><a href="https://www.youtube.com/watch?v=cwBBe_rfTd8" target="_blank">Build A Restaurant Viewing App</a></h1>

## Demo

<img src="https://i.imgur.com/9thpBwq.gif" width="350" height="650">

### What you will learn:
- Auto layout
- CoreLocation
- Alamofire
- Master Detail
